# bookFormDialog.py
from PySide6.QtWidgets import (
    QWidget,
    QLineEdit,
    QToolButton,
    QPushButton,
    QDialog,
    QTextEdit,
)
from PySide6.QtGui import QPixmap
from pages.bookManagement.ui_form import Ui_Dialog


class BookFormDialog(QDialog, Ui_Dialog):
    def __init__(self, parent=None, book=None):
        super().__init__(parent)
        self.ui = Ui_Dialog()
        self.book = book
        self.setupUi(self)
        self.setupDialogUi()

    def setupDialogUi(self):
        if self.book:
            self.setWindowTitle("Edit Book")
            self.bookFormDialogTitle.setText("Edit Book")
        else:
            self.setWindowTitle("Create Book")
            self.bookFormDialogTitle.setText("Create Book")

        # Set up the form fields
        # self.bookTitleInput = self.findChild(QLineEdit, "bookTitleInput")
        # self.bookDescriptionInput = self.findChild(QTextEdit, "bookDescriptionInput")
        # self.createBookButton = self.findChild(QPushButton, "createBookButton")
        # self.cancelBookButton = self.findChild(QPushButton, "cancelBookButton")

        # Connect signals
        self.connectSignals()
        self.populateForm()

    def connectSignals(self):
        self.createBookButton.clicked.connect(self.accept)
        self.cancelBookButton.clicked.connect(self.reject)

    def populateForm(self):
        if self.book:
            self.bookTitleInput.setText(self.book["title"])
            self.bookDescriptionInput.setText(self.book["description"])
            self.bookAuthorInput.setText(self.book["author"])
            self.bookPublisherInput.setText(self.book["publisher"])
            self.bookYearInput.setText(str(self.book["year"]))
            self.bookIsbnInput.setText(self.book["isbn"])
            self.bookGenreInput.setText(self.book["genre"])
            self.bookLanguageInput.setText(self.book["language"])
            # self.bookPagesInput.setText(self.book["pages"])

        if self.book and self.book["cover"] != "":
            placeholderPixmap = QPixmap(self.book["cover"])
        else:
            placeholderPixmap = QPixmap("assets/images/placeholder.png")

        self.bookCoverPlaceholder.setPixmap(placeholderPixmap)

    def getFormData(self):
        return {
            "title": self.bookTitleInput.text(),
            "description": self.bookDescriptionInput.text(),
            "author": self.bookAuthorInput.text(),
            "publisher": self.bookPublisherInput.text(),
            "year": self.bookYearInput.text(),
            "isbn": self.bookIsbnInput.text(),
            "genre": self.bookGenreInput.text(),
            "language": self.bookLanguageInput.text(),
            "stock": 1
            # "pages": self.bookPagesInput.text()
        }
