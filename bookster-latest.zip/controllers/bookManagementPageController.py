# bookManagement.py
from PySide6.QtWidgets import QWidget, QLineEdit, QToolButton
from PySide6.QtGui import QIcon
from PySide6.QtCore import QSize
from customWidgets.bookCardList import BookCardList
from helpers.dataReader import DataReader

from pages.bookManagement.bookFormDialog import BookFormDialog


class BookManagementPageController:
    def __init__(self, mainWindow):
        self.mainWindow = mainWindow
        self.dataReader = DataReader("data/books.json")
        self.books = self.dataReader.get()

        self.setupUi()
        self.connectSignals()
        self.populateBookList(self.books)

    def setupUi(self):
        self.bookListScrollArea = self.getBookListScrollArea()
        self.bookListScrollContent = self.bookListScrollArea.widget()
        self.bookListScrollLayout = self.bookListScrollContent.layout()
        self.searchBookInput = self.getSearchBookInput()
        self.addBookButton = self.getAddBookButton()
        self.bookManagementBackButton = self.getBackButton()
        self.bookPageDescription = self.getBookPageDescription()

        plusIcon = QIcon("assets/icons/plus.svg")
        self.addBookButton.setIcon(plusIcon)
        self.addBookButton.setIconSize(QSize(20, 20))

        backIcon = QIcon("assets/icons/arrow-narrow-left.svg")
        self.bookManagementBackButton.setIcon(backIcon)
        self.bookManagementBackButton.setIconSize(QSize(20, 20))

    def connectSignals(self):
        self.searchBookInput.textChanged.connect(self.onSearchBookInputChanged)
        self.bookManagementBackButton.clicked.connect(
            lambda: self.mainWindow.stackedWidget.setCurrentWidget(
                self.mainWindow.mainPage
            )
        )
        self.addBookButton.clicked.connect(self.openAddBookDialog)


    def getBookListScrollArea(self):
        return self.mainWindow.findChild(QWidget, "bookListScrollArea")

    def getSearchBookInput(self):
        return self.mainWindow.findChild(QLineEdit, "searchBookInput")

    def getAddBookButton(self):
        return self.mainWindow.findChild(QToolButton, "addBookButton")

    def getBackButton(self):
        return self.mainWindow.findChild(QToolButton, "bookManagementBackButton")

    def getBookPageDescription(self):
        return self.mainWindow.findChild(QWidget, "bookPageDescription")

    def onSearchBookInputChanged(self, text):
        filteredBooks = [
            book
            for book in self.books
            if text.lower() in book["title"].lower()
            or text.lower() in book["author"].lower()
        ]
        self.populateBookList(filteredBooks)

    def populateBookList(self, books):
        while self.bookListScrollLayout.count():
            child = self.bookListScrollLayout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        for book in books:
            card = BookCardList(book["title"], book["author"])
            self.bookListScrollLayout.addWidget(card)

        self.bookListScrollLayout.addStretch()

        if len(books) > 1:
            self.bookPageDescription.setText(f"{len(books)} Books Available")
        elif len(books) == 1:
            self.bookPageDescription.setText(f"{len(books)} Book Available")
        else:
            self.bookPageDescription.setText("No Book Available")

    def openAddBookDialog(self):
        dialog = BookFormDialog(self.mainWindow)
        if dialog.exec():
            newBook = dialog.getFormData()
            self.dataReader.addItem(newBook)  # Save to JSON
            self.books = self.dataReader.get()
            self.populateBookList(self.books)
